export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  /** Go High Level CRM webhook URL for lead delivery */
  ghlWebhookUrl: process.env.GHL_WEBHOOK_URL ?? "",
  /** Resend API key for transactional email notifications */
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  /** Admin dashboard PIN (server-side only, never exposed to frontend) */
  adminPin: process.env.ADMIN_PIN ?? "",
};
